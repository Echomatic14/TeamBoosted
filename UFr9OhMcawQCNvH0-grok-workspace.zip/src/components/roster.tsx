import { discordUrl } from "@/data/team";

export function Roster() {
  return (
    <section id="roster" className="scroll-mt-24 border-t border-line px-5 py-16 md:py-24">
      <div className="mx-auto max-w-6xl">
        <p className="text-sm font-semibold tracking-widest text-accent uppercase">Lineup</p>
        <h2 className="mt-2 text-5xl leading-none font-bold text-fg md:text-6xl">Roster</h2>
        <div className="mt-10 rounded-xl border border-line bg-surface p-6 md:p-8">
          <p className="font-display text-3xl font-bold text-fg">No roster yet.</p>
          <p className="mt-3 max-w-lg text-base leading-relaxed text-muted">
            Seats are empty on purpose. Names go up here when they're actually on the team.
          </p>
          <a
            href={discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex min-h-11 items-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-fg hover:opacity-90"
          >
            Join Discord
          </a>
        </div>
      </div>
    </section>
  );
}
