import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { Roster } from "@/components/roster";
import { Matches } from "@/components/matches";
import { Tryouts } from "@/components/tryouts";
import { principles, discordUrl } from "@/data/team";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div id="top" className="bg-bg text-fg">
      <SiteHeader />
      <main>
        <section className="relative min-h-screen">
          <img
            src="/media/arena.jpg"
            alt=""
            width={1920}
            height={1080}
            className="absolute inset-0 h-full w-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/25 md:bg-gradient-to-r md:from-bg/90 md:via-bg/35 md:to-transparent" />
          <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-bg to-transparent" />
          <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-bg/70 to-transparent" />
          <div className="relative z-10 mx-auto flex min-h-screen max-w-6xl flex-col justify-end px-5 pt-24 pb-10 md:justify-center">
            <p className="text-sm font-semibold tracking-widest text-fg uppercase">Rocket League</p>
            <h1 className="mt-4 max-w-md">
              <img
                src="/media/logo-white.png"
                alt="Team Boosted"
                width={1400}
                height={978}
                className="logo-mark w-full"
              />
            </h1>
            <p className="mt-5 max-w-md text-lg leading-relaxed text-fg">
              Rocket League. The logo's locked. The lineup isn't.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <a
                href={discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-11 items-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-fg hover:opacity-90"
              >
                Join Discord
              </a>
              <a
                href="#about"
                className="inline-flex min-h-11 items-center rounded-full border border-line bg-bg/70 px-5 text-sm font-semibold text-fg hover:bg-bg"
              >
                About the team
              </a>
            </div>
            <dl className="mt-12 grid max-w-xl grid-cols-3 gap-4 border-t border-line/80 pt-6">
              <div>
                <dt className="text-sm text-muted">Game</dt>
                <dd className="mt-1 font-display text-2xl font-bold text-fg">3v3</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">Roster</dt>
                <dd className="mt-1 font-display text-2xl font-bold text-fg">Open</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">Next</dt>
                <dd className="mt-1 font-display text-2xl font-bold text-fg">None</dd>
              </div>
            </dl>
          </div>
        </section>

        <Roster />
        <Matches />

        <section id="about" className="scroll-mt-24 border-t border-line px-5 py-16 md:py-24">
          <div className="mx-auto grid max-w-6xl gap-12 md:grid-cols-2">
            <div>
              <p className="text-sm font-semibold tracking-widest text-accent uppercase">The team</p>
              <h2 className="mt-2 text-5xl leading-none font-bold text-fg md:text-6xl">
                Built for the boost
              </h2>
              <p className="mt-5 max-w-md text-base leading-relaxed text-muted">
                Team Boosted is a Rocket League side. The roster isn't set and nothing is on the
                schedule. This page stays empty until both are real.
              </p>
              <p className="mt-4 max-w-md text-base leading-relaxed text-muted">
                If you want in, join the Discord. When a match gets booked, it shows up above.
              </p>
            </div>
            <ol className="grid gap-4">
              {principles.map((item) => (
                <li key={item.n} className="rounded-xl border border-line bg-surface p-5">
                  <p className="font-display text-sm font-bold tracking-widest text-accent">
                    {item.n}
                  </p>
                  <h3 className="mt-2 text-3xl font-bold text-fg">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{item.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <Tryouts />
      </main>
      <footer className="border-t border-line px-5 py-8">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <img
            src="/media/logo-white.png"
            alt=""
            width={1400}
            height={978}
            className="h-8 w-auto"
          />
          <a
            href={discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-medium text-fg hover:text-accent"
          >
            Discord
          </a>
        </div>
      </footer>
    </div>
  );
}
