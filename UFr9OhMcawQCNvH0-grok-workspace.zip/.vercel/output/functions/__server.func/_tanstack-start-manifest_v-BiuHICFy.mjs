//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BiuHICFy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CJNBV6d6.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CJNBV6d6.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CmN-EeAJ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
