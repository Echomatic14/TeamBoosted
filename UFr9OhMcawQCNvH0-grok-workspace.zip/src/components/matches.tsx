export function Matches() {
  return (
    <section id="matches" className="scroll-mt-24 border-t border-line bg-surface px-5 py-16 md:py-24">
      <div className="mx-auto max-w-6xl">
        <p className="text-sm font-semibold tracking-widest text-accent uppercase">Schedule</p>
        <h2 className="mt-2 text-5xl leading-none font-bold text-fg md:text-6xl">Matches</h2>
        <div className="mt-10 rounded-xl border border-line p-6 md:p-8">
          <p className="font-display text-3xl font-bold text-fg">Nothing booked.</p>
          <p className="mt-3 max-w-lg text-base leading-relaxed text-muted">
            No upcoming match and no results to post. The list stays blank until a lobby is real.
          </p>
        </div>
      </div>
    </section>
  );
}
