export const discordUrl = "https://discord.gg/qSNjUpdr3D";

export const principles = [
  {
    n: "01",
    title: "Rotate, then boost",
    body: "The first touch only works if someone is already behind it.",
  },
  {
    n: "02",
    title: "Short comms",
    body: "I got it. Need boost. Fake. That's the whole dictionary.",
  },
  {
    n: "03",
    title: "On time",
    body: "Warmup starts before the lobby. Kickoff is not a surprise.",
  },
];
