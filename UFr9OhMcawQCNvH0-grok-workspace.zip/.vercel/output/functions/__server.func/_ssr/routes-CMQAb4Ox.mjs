import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Menu, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CMQAb4Ox.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		href: "#roster",
		label: "Roster"
	},
	{
		href: "#matches",
		label: "Matches"
	},
	{
		href: "#about",
		label: "About"
	},
	{
		href: "#tryouts",
		label: "Tryouts"
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "fixed inset-x-0 top-0 z-30 border-b border-line/80 bg-bg/80 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/media/mark.png",
						alt: "",
						width: 280,
						height: 160,
						className: "h-8 w-auto"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl leading-none font-bold tracking-wide text-fg",
						children: "BOOSTED"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-7 md:flex",
					"aria-label": "Primary",
					children: [links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						className: "text-sm font-medium text-muted transition-colors duration-200 hover:text-fg",
						children: link.label
					}, link.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#tryouts",
						className: "rounded-full bg-accent px-4 py-2 text-sm font-semibold text-accent-fg transition-opacity duration-200 hover:opacity-90",
						children: "Join the lobby"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center rounded-full border border-line text-fg md:hidden",
					"aria-expanded": open,
					"aria-label": open ? "Close menu" : "Open menu",
					onClick: () => setOpen((v) => !v),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 20 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 20 })
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "border-t border-line bg-bg px-5 py-3 md:hidden",
			"aria-label": "Mobile",
			children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: link.href,
				className: "flex min-h-11 items-center text-base font-medium text-fg",
				onClick: () => setOpen(false),
				children: link.label
			}, link.href))
		}) : null]
	});
}
function Roster() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "roster",
		className: "scroll-mt-24 border-t border-line px-5 py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold tracking-widest text-accent uppercase",
					children: "Lineup"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-5xl leading-none font-bold text-fg md:text-6xl",
					children: "Roster"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 rounded-xl border border-line bg-surface p-6 md:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-bold text-fg",
							children: "No roster yet."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-lg text-base leading-relaxed text-muted",
							children: "Seats are empty on purpose. Names go up here when they're actually on the team."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#tryouts",
							className: "mt-6 inline-flex min-h-11 items-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-fg hover:opacity-90",
							children: "Ask for a look"
						})
					]
				})
			]
		})
	});
}
function Matches() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "matches",
		className: "scroll-mt-24 border-t border-line bg-surface px-5 py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold tracking-widest text-accent uppercase",
					children: "Schedule"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-5xl leading-none font-bold text-fg md:text-6xl",
					children: "Matches"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 rounded-xl border border-line p-6 md:p-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-bold text-fg",
						children: "Nothing booked."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-lg text-base leading-relaxed text-muted",
						children: "No upcoming match and no results to post. The list stays blank until a lobby is real."
					})]
				})
			]
		})
	});
}
var STORAGE_KEY = "team-boosted-tryout";
var ranks = [
	"Diamond",
	"Champion",
	"Grand Champion",
	"Supersonic Legend"
];
var roles = [
	"Striker",
	"Second man",
	"Third man",
	"Flex"
];
function Tryouts() {
	const [tag, setTag] = (0, import_react.useState)("");
	const [rank, setRank] = (0, import_react.useState)(ranks[1]);
	const [role, setRole] = (0, import_react.useState)(roles[3]);
	const [saved, setSaved] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) setSaved(JSON.parse(raw));
		} catch {}
		setReady(true);
	}, []);
	function submit(e) {
		e.preventDefault();
		const clean = tag.trim();
		if (clean.length < 2) {
			setError("Add a gamertag so the lobby can find you.");
			return;
		}
		const note = {
			tag: clean,
			rank,
			role
		};
		localStorage.setItem(STORAGE_KEY, JSON.stringify(note));
		setSaved(note);
		setError("");
		setTag("");
	}
	function clear() {
		localStorage.removeItem(STORAGE_KEY);
		setSaved(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "tryouts",
		className: "scroll-mt-24 border-t border-line px-5 py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 md:grid-cols-2 md:items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold tracking-widest text-accent uppercase",
					children: "Open"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-5xl leading-none font-bold text-fg md:text-6xl",
					children: "Tryouts"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-base leading-relaxed text-muted",
					children: "No lineup yet, so tryouts are how you get on it. Your tag stays on this device."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-line bg-surface p-5 md:p-6",
				children: !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-48",
					"aria-hidden": "true"
				}) : saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-wide text-muted uppercase",
						children: "Saved note"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-4xl leading-none font-bold text-fg",
						children: saved.tag
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-base text-fg",
						children: [
							saved.role,
							" · ",
							saved.rank
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Saved on this device. That's it until a lobby exists."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: clear,
						className: "mt-6 min-h-11 rounded-full border border-line px-4 text-sm font-medium text-fg hover:bg-surface-2",
						children: "Clear and rewrite"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-2 text-sm font-medium text-fg",
							children: ["Gamertag", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: tag,
								onChange: (e) => setTag(e.target.value),
								maxLength: 24,
								autoComplete: "nickname",
								placeholder: "Your in-game name",
								className: "min-h-11 rounded-lg border border-line bg-bg px-4 text-base font-normal text-fg placeholder:text-muted"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-2 text-sm font-medium text-fg",
								children: ["Rank", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: rank,
									onChange: (e) => setRank(e.target.value),
									className: "min-h-11 rounded-lg border border-line bg-bg px-4 text-base font-normal text-fg",
									children: ranks.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-2 text-sm font-medium text-fg",
								children: ["Role", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: role,
									onChange: (e) => setRole(e.target.value),
									className: "min-h-11 rounded-lg border border-line bg-bg px-4 text-base font-normal text-fg",
									children: roles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
								})]
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-accent",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "min-h-11 rounded-full bg-accent px-5 text-sm font-semibold text-accent-fg hover:opacity-90",
							children: "Save my tryout note"
						})
					]
				})
			})]
		})
	});
}
var principles = [
	{
		n: "01",
		title: "Rotate, then boost",
		body: "The first touch only works if someone is already behind it."
	},
	{
		n: "02",
		title: "Short comms",
		body: "I got it. Need boost. Fake. That's the whole dictionary."
	},
	{
		n: "03",
		title: "On time",
		body: "Warmup starts before the lobby. Kickoff is not a surprise."
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		className: "bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative min-h-screen",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/media/arena.jpg",
							alt: "",
							width: 1920,
							height: 1080,
							className: "absolute inset-0 h-full w-full object-cover object-center"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/25 md:bg-gradient-to-r md:from-bg/90 md:via-bg/35 md:to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-bg to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-bg/70 to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 mx-auto flex min-h-screen max-w-6xl flex-col justify-end px-5 pt-24 pb-10 md:justify-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold tracking-widest text-fg uppercase",
									children: "Rocket League"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-4 max-w-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/media/logo-white.png",
										alt: "Team Boosted",
										width: 1400,
										height: 978,
										className: "logo-mark w-full"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-md text-lg leading-relaxed text-fg",
									children: "Rocket League. The logo's locked. The lineup isn't."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-7 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#tryouts",
										className: "inline-flex min-h-11 items-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-fg hover:opacity-90",
										children: "Tryouts"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#about",
										className: "inline-flex min-h-11 items-center rounded-full border border-line bg-bg/70 px-5 text-sm font-semibold text-fg hover:bg-bg",
										children: "About the team"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-12 grid max-w-xl grid-cols-3 gap-4 border-t border-line/80 pt-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-sm text-muted",
											children: "Game"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-display text-2xl font-bold text-fg",
											children: "3v3"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-sm text-muted",
											children: "Roster"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-display text-2xl font-bold text-fg",
											children: "Open"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-sm text-muted",
											children: "Next"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-display text-2xl font-bold text-fg",
											children: "None"
										})] })
									]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roster, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matches, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "about",
					className: "scroll-mt-24 border-t border-line px-5 py-16 md:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-12 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold tracking-widest text-accent uppercase",
								children: "The team"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-5xl leading-none font-bold text-fg md:text-6xl",
								children: "Built for the boost"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-md text-base leading-relaxed text-muted",
								children: "Team Boosted is a Rocket League side. The roster isn't set and nothing is on the schedule. This page stays empty until both are real."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-md text-base leading-relaxed text-muted",
								children: "If you want in, leave a tag in tryouts. When a match gets booked, it shows up above."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "grid gap-4",
							children: principles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-xl border border-line bg-surface p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-sm font-bold tracking-widest text-accent",
										children: item.n
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 text-3xl font-bold text-fg",
										children: item.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: item.body
									})
								]
							}, item.n))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tryouts, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line px-5 py-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/media/logo-white.png",
						alt: "",
						width: 1400,
						height: 978,
						className: "h-8 w-auto"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Team Boosted · Rocket League"
					})]
				})
			})
		]
	});
}
//#endregion
export { Home as component };
