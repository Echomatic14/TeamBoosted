import { discordUrl } from "@/data/team";

export function Tryouts() {
  return (
    <section id="tryouts" className="scroll-mt-24 border-t border-line px-5 py-16 md:py-24">
      <div className="mx-auto grid max-w-6xl gap-10 md:grid-cols-2 md:items-start">
        <div>
          <p className="text-sm font-semibold tracking-widest text-accent uppercase">Open</p>
          <h2 className="mt-2 text-5xl leading-none font-bold text-fg md:text-6xl">Tryouts</h2>
          <p className="mt-4 max-w-md text-base leading-relaxed text-muted">
            No lineup yet. Hop in the Discord if you want a look.
          </p>
        </div>
        <div className="rounded-xl border border-line bg-surface p-6 md:p-8">
          <p className="text-sm font-medium tracking-wide text-muted uppercase">Discord</p>
          <p className="mt-3 font-display text-4xl leading-none font-bold text-fg">Team Boosted</p>
          <p className="mt-3 text-base leading-relaxed text-muted">
            The server is where tryouts, lobbies, and roster talk happen.
          </p>
          <a
            href={discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex min-h-11 items-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-fg hover:opacity-90"
          >
            Join the server
          </a>
        </div>
      </div>
    </section>
  );
}
