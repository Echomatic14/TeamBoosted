import { useState } from "react";
import { Menu, X } from "lucide-react";
import { discordUrl } from "@/data/team";

const links = [
  { href: "#roster", label: "Roster" },
  { href: "#matches", label: "Matches" },
  { href: "#about", label: "About" },
  { href: "#tryouts", label: "Tryouts" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed inset-x-0 top-0 z-30 border-b border-line/80 bg-bg/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#top" className="flex items-center gap-2">
          <img src="/media/mark.png" alt="" width={280} height={160} className="h-8 w-auto" />
          <span className="font-display text-2xl leading-none font-bold tracking-wide text-fg">
            BOOSTED
          </span>
        </a>
        <nav className="hidden items-center gap-7 md:flex" aria-label="Primary">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-muted transition-colors duration-200 hover:text-fg"
            >
              {link.label}
            </a>
          ))}
          <a
            href={discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-full bg-accent px-4 py-2 text-sm font-semibold text-accent-fg transition-opacity duration-200 hover:opacity-90"
          >
            Discord
          </a>
        </nav>
        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-full border border-line text-fg md:hidden"
          aria-expanded={open}
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
      {open ? (
        <nav className="border-t border-line bg-bg px-5 py-3 md:hidden" aria-label="Mobile">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="flex min-h-11 items-center text-base font-medium text-fg"
              onClick={() => setOpen(false)}
            >
              {link.label}
            </a>
          ))}
          <a
            href={discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex min-h-11 items-center text-base font-semibold text-accent"
          >
            Discord
          </a>
        </nav>
      ) : null}
    </header>
  );
}
